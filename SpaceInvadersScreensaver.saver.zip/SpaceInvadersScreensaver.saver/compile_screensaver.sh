#!/bin/bash

# Space Invaders Screensaver - Script de Compilación
# Para macOS Ventura (13.0) a Sequoia/Tahoe (15.0+)

set -e

echo "=== Compilando Space Invaders Screensaver ==="

# Directorio del proyecto
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
SAVER_BUNDLE="$PROJECT_DIR/SpaceInvadersScreensaver.saver"

echo "Compilando SpaceInvadersScreensaver.swift..."

swiftc -target x86_64-apple-macosx13.0 \
    -target arm64-apple-macosx13.0 \
    -framework Cocoa \
    -framework ScreenSaver \
    -framework WebKit \
    -emit-library \
    -o "$SAVER_BUNDLE/Contents/MacOS/SpaceInvadersScreensaver" \
    "$PROJECT_DIR/SpaceInvadersScreensaver.swift"

# Verificar que se compiló correctamente
if [ -f "$SAVER_BUNDLE/Contents/MacOS/SpaceInvadersScreensaver" ]; then
    echo "✓ Compilación exitosa!"
    echo ""
    echo "Para instalar el screensaver:"
    echo "1. Abre el Finder y ve a la carpeta del proyecto"
    echo "2. Haz doble clic en SpaceInvadersScreensaver.saver"
    echo "3. Elige 'Instalar para este usuario' o 'Instalar para todos los usuarios'"
    echo "4. Ve a Preferencias del Sistema > Salvapantallas"
    echo "5. Selecciona 'Space Invaders' de la lista"
    echo ""
    echo "¡Listo! Ahora tu Mac tiene Space Invaders como screensaver"
else
    echo "✗ Error en la compilación"
    exit 1
fi
